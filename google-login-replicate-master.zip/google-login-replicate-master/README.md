# google-login-replicate
Just tried to replicate a Google's Awesome Login and Register pages using Cash.js, Material Design and Routie.js

Credits:

https://github.com/kenwheeler/cash

http://materializecss.com

http://projects.jga.me/routie

Demo: https://pandiarajankv.github.io/google-login-replicate/

jQuery version of this available here: https://w3lessons.info/new-gmail-style-login-registration-form-with-material-design-jquery-html-css/
